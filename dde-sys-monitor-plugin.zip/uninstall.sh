#!/bin/bash
sudo rm /usr/lib/dde-dock/plugins/libsys_monitor.so
killall dde-dock